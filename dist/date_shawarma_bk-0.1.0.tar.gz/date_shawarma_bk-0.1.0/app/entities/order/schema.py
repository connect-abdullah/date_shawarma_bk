from datetime import datetime
from pydantic import BaseModel
from app.entities.order.model import OrderStatusEnum, PaymentMethodEnum

class OrderItemBase(BaseModel):
    product_id: int
    variant_id: int | None = None  # which size/variant from the menu.json
    quantity: int
    unit_price: float


class OrderItemRead(OrderItemBase):
    id: int
    order_id: int

    class Config:
        from_attributes = True


class OrderBase(BaseModel):
    customer_id: int
    order_status: OrderStatusEnum
    order_date: datetime
    total_price: float


class OrderCreate(BaseModel):
    total_price: float
    payment_method: PaymentMethodEnum
    items: list[OrderItemBase]


class OrderUpdate(BaseModel):
    order_status: OrderStatusEnum | None = None


class OrderRead(OrderBase):
    id: int

    class Config:
        from_attributes = True


class ListItems(BaseModel):
    id: int
    product_id: int
    product_name: str
    variant_id: int | None = None
    variant_name: str | None = None
    quantity: int
    unit_price: float
    order_id: int
    total_price: float
    payment_method: PaymentMethodEnum | str | None = None
    customer_name: str | None = None
    customer_address: str | None = None
    created_at: datetime
    

class OrderReadWithItems(OrderRead):
    order_items: list[ListItems] = []  # noqa: RUF012

    class Config:
        from_attributes = True
